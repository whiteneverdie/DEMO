Downloaded From: http://proj.ise.bgu.ac.il/sns

Students� Cooperation Social Network was constructed from the data collected during a �Computer and Network Security� course; a mandatory course at Ben-Gurion University. The social network contains data collected from 185 participating students from two different departments. The course�s social network was created by analyzing the implicit and explicit cooperation among the students while doing their homework assignments. 
The students� cooperation graph contained 185 nodes and 360 links and 3 types of links.
Please Cite:

Predicting Student Exam's Scores by Analyzing Social Network Data , Michael Fire, Gilad Katz, Yuval Elovici, Bracha Shapira, and Lior Rokach, 2012.
Bibtex:
@article{

title={Predicting Student Exam's Scores by Analyzing Social Network Data},
author={Michael Fire, Gilad Katz, Yuval Elovici, Bracha Shapira, and Lior Rokach},
year={2012}
}
